data:extend({
 {
    type = "recipe",
    name = "bullet-bill",
    enabled = "false",
    ingredients = 
    {
      {"diesel-locomotive",1},
      {"piercing-bullet-magazine",1}
    },
    result = "bullet-bill"
  }
})
