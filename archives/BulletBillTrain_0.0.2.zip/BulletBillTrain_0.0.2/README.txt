Bullet Bill Train
v 0.0.2

Created by Charlie Dobbie in response to a comment by ElricM (https://www.twitch.tv/elricm).

This is a very simple mod that essentially just adds a cosmetic alternative to the diesel engine.

3D model created by Captain J and used under CC BY-NC-ND 3.0 licence.  Found on TinkerCAD:

* https://www.tinkercad.com/things/fQG0UERaYBm-bullet-bill
