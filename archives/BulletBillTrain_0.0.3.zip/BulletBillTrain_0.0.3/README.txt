Bullet Bill Train
v 0.0.3

Created by Charlie Dobbie in response to a comment made by ElricM
(https://www.twitch.tv/elricm).

This is a very simple mod that offers an alternative to the diesel
locomotive.  This "bullet train" accelerates and decelerates faster
than a standard locomotive, and has a slightly higher top speed.
It also burns through fuel twice as fast.

It's intended to make crossing the tracks on a yellow signal that
little bit more terrifying.  After all, if your base isn't trying
to kill you, you've done something wrong.

3D model created by Captain J and used under CC BY-NC-ND 3.0 licence.
Found on TinkerCAD:

* https://www.tinkercad.com/things/fQG0UERaYBm-bullet-bill

