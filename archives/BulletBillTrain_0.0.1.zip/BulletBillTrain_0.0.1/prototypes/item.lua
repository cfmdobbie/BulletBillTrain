data:extend({

 {
    type = "item",
    name = "bullet-bill",
    icon = "__BulletBillTrain__/graphics/icon_bulletbill.png",
    flags = { "goes-to-quickbar" },
    subgroup = "transport",
    place_result="bullet-bill",
    stack_size= 5,
  }

})

