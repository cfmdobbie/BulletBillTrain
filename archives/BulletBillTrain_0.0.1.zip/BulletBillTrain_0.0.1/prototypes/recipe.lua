data:extend({
 {
    type = "recipe",
    name = "bullet-bill",
    enabled = "true",
    ingredients = 
    {
      {"diesel-locomotive",1},
      {"piercing-bullet-magazine",1}
    },
    result = "bullet-bill"
  }
})
